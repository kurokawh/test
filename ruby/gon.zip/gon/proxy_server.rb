#!/usr/bin/env ruby
#
# proxy_server.rb [HOST_IP_ADDRESS LISTEN_PORT]
# - HOST_IP_ADDRESS: if not set or "" or "-" is set, IP is obtained.
# - LISTEN_PORT: 8080 is set by default
#

require 'webrick'
require 'webrick/httpproxy'
include WEBrick

def debug_puts(x)
	puts("[DEBUG]: " + x)
	STDOUT.flush
end

if ARGV[0] != nil && ARGV[0] != "" && ARGV[0] != "-"
	$HOST_IP_ADDRESS = ARGV[0]
else
	$HOST_IP_ADDRESS = Socket.getaddrinfo(Socket::gethostname, nil, Socket::AF_INET)[0][3]
	#"127.0.0.1"
end
if ARGV[1] != nil
	$LISTEN_PORT = ARGV[1].to_i
else
	$LISTEN_PORT = 8080
end

puts("")
puts("start proxy server!")
puts("- host ip: " + $HOST_IP_ADDRESS)
puts("- port no: " + $LISTEN_PORT.to_s)
puts("proxy setting:")
port_string = ""
if $LISTEN_PORT != 80
	port_string = ":" + $LISTEN_PORT.to_s
end
puts("  http://"+$HOST_IP_ADDRESS + port_string)
puts("signal ctrl-c to stop server.")
puts("")



s = HTTPProxyServer.new({ :BindAddress => $HOST_IP_ADDRESS, :Port => $LISTEN_PORT })
trap("INT"){ s.shutdown }
s.start
