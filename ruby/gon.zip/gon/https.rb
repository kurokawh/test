#!/usr/bin/env ruby
require 'webrick'
require 'webrick/https'

server = WEBrick::HTTPServer.new(
    :BindAddress => '192.168.92.190', #'127.0.0.1',
    :Port => 3000,
    :DocumentRoot => '.',
    :SSLEnable  => true,
    :SSLCertName  => [ [ 'CN', WEBrick::Utils::getservername ] ])
Signal.trap('INT') { server.shutdown }
server.start
