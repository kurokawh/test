#!/usr/bin/env ruby
#
# delay_server.rb [HOST_IP_ADDRESS LISTEN_PORT DELAY_TIME_MS]
# - HOST_IP_ADDRESS: if not set or "" or "-" is set, IP is obtained.
# - LISTEN_PORT: 8080 is set by default
# - DELAY_TIME_MS: sleep this time (ms) everytime sending data to client. default is 100(ms).
# 
# this proxy server emulates narrow band network.
# sleep 100 (ms) by default for everytime 4KB block is sent to client.
#

require 'webrick'
require 'webrick/httpproxy'
include WEBrick

def debug_puts(x)
	puts("[DEBUG]: " + x)
	STDOUT.flush
end

if ARGV[0] != nil && ARGV[0] != "" && ARGV[0] != "-"
	$HOST_IP_ADDRESS = ARGV[0]
else
	$HOST_IP_ADDRESS = IPSocket::getaddress(Socket::gethostname) #"127.0.0.1"
end
if ARGV[1] != nil
	$LISTEN_PORT = ARGV[1].to_i
else
	$LISTEN_PORT = 8080
end
if ARGV[2] != nil
	$DELAY_TIME_MS = ARGV[1].to_i
else
	$DELAY_TIME_MS = 100
end

puts("")
puts("start proxy server!")
puts("- host ip: " + $HOST_IP_ADDRESS)
puts("- port no: " + $LISTEN_PORT.to_s)
puts("- delay  : " + $DELAY_TIME_MS.to_s + " (ms)")
puts("proxy setting:")
port_string = ""
if $LISTEN_PORT != 80
	port_string = ":" + $LISTEN_PORT.to_s
end
puts("  http://"+$HOST_IP_ADDRESS + port_string)
puts("signal ctrl-c to stop server.")
puts("")


module WEBrick
  class HTTPResponse
    def _write_data(socket, data)
		debug_puts "sleep " + $DELAY_TIME_MS.to_s + " (ms)"
		sleep 0.1
		debug_puts "done"
		socket << data
		socket.flush
    end
  end
end

s = HTTPProxyServer.new({ :BindAddress => $HOST_IP_ADDRESS, :Port => $LISTEN_PORT })
trap("INT"){ s.shutdown }
s.start
